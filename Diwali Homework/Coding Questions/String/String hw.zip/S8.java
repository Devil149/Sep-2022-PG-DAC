import java.util.*;
class S8 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a String : ");
		String str = sc.nextLine();
		
		Integer a = Integer.parseInt(str);
		System.out.println("Converted string to integer : "+a);
		
	}
}